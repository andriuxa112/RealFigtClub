import { readFileSync } from "node:fs";
import { PGlite } from "@electric-sql/pglite";
import {
  beforeAll,
  beforeEach,
  afterAll,
  afterEach,
  describe,
  it,
  expect,
} from "vitest";
let db: PGlite;
const coach = "11000000-0000-4000-8000-000000000001";
const other = "11000000-0000-4000-8000-000000000002";
const admin = "11000000-0000-4000-8000-000000000003";
const club = "c0000000-0000-4000-8000-000000000001";
const ownAthlete = "a0000000-0000-4000-8000-000000000001";
const foreignAthlete = "a0000000-0000-4000-8000-000000000002";
const event = "f0000000-0000-4000-8000-000000000001";
const discipline = "d0000000-0000-4000-8000-000000000001";
const experience = "e0000000-0000-4000-8000-000000000001";
const category = "b0000000-0000-4000-8000-000000000001";
beforeAll(async () => {
  db = new PGlite();
  await db.exec(
    `create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key,raw_user_meta_data jsonb default '{}');create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth,public to authenticated;grant execute on function auth.uid() to authenticated;`,
  );
  const migration = readFileSync(
    new URL("../supabase/migrations/202611150001_initial.sql", import.meta.url),
    "utf8",
  ).replace("create extension if not exists pgcrypto;", "");
  await db.exec(migration);
  await db.exec(
    `insert into auth.users(id) values('${coach}'),('${other}'),('${admin}');update public.profiles set role='ADMIN' where id='${admin}';`,
  );
  await db.exec(
    readFileSync(new URL("../supabase/seed.sql", import.meta.url), "utf8"),
  );
  await db.exec(
    `insert into public.club_members(club_id,user_id) values('${club}','${coach}'),('c0000000-0000-4000-8000-000000000002','${other}');insert into public.categories(id,event_id,discipline_id,name,gender,min_age,max_age,min_weight,max_weight,experience_level) values('${category}','${event}','${discipline}','Precise test','MALE',0,120,60,65,'${experience}');`,
  );
});
beforeEach(async () => {
  await db.exec("begin;");
});
afterEach(async () => {
  await db.exec("rollback;");
});
afterAll(async () => {
  await db.close();
});
async function asUser(id: string) {
  await db.exec(
    `set local role authenticated;select set_config('request.jwt.claim.sub','${id}',true);`,
  );
}
async function insertRegistration(
  overrides: {
    athlete?: string;
    status?: string;
    weight?: number;
    category?: string | null;
  } = {},
) {
  const cid =
    overrides.category === null ? null : (overrides.category ?? category);
  return db.query(
    `insert into public.registrations(event_id,athlete_id,discipline_id,category_id,declared_weight,experience_level,total_fights,total_wins,status) values($1,$2,$3,$4,$5,$6,3,1,$7) returning id`,
    [
      event,
      overrides.athlete ?? ownAthlete,
      discipline,
      cid,
      overrides.weight ?? 65,
      experience,
      overrides.status ?? "SUBMITTED",
    ],
  );
}
describe("Real PostgreSQL policies and constraints", () => {
  it("coach can register own athlete", async () => {
    await asUser(coach);
    const result = await insertRegistration();
    expect(result.rows).toHaveLength(1);
  });
  it("coach cannot read or edit other club athlete", async () => {
    await asUser(coach);
    expect(
      (
        await db.query("select id from public.athletes where id=$1", [
          foreignAthlete,
        ])
      ).rows,
    ).toHaveLength(0);
    expect(
      (
        await db.query(
          "update public.athletes set first_name=$1 where id=$2 returning id",
          ["Changed", foreignAthlete],
        )
      ).rows,
    ).toHaveLength(0);
  });
  it("coach cannot insert another club athlete", async () => {
    await asUser(coach);
    await expect(
      db.query(
        `insert into public.athletes(club_id,first_name,last_name,date_of_birth,gender) values('c0000000-0000-4000-8000-000000000002','X','Y','2000-01-01','MALE')`,
      ),
    ).rejects.toThrow(/row-level security/);
  });
  it("coach cannot register another club athlete", async () => {
    await asUser(coach);
    await expect(
      insertRegistration({ athlete: foreignAthlete }),
    ).rejects.toThrow(/FORBIDDEN|row-level/);
  });
  it("database rejects duplicate registration", async () => {
    await asUser(coach);
    await insertRegistration();
    await expect(insertRegistration()).rejects.toThrow(/unique/);
  });
  it("coach cannot approve own registration", async () => {
    await asUser(coach);
    await expect(insertRegistration({ status: "APPROVED" })).rejects.toThrow(
      /FORBIDDEN_STATUS/,
    );
  });
  it("admin can create and archive event", async () => {
    await asUser(admin);
    const result = await db.query(
      `insert into public.events(name,location,start_date,end_date,registration_deadline,mode) values('Admin event','Test',current_date+20,current_date+20,now()+interval '10 days','CHAMPIONSHIP') returning id`,
    );
    expect(result.rows).toHaveLength(1);
    expect(
      (
        await db.query(
          `update public.events set archived=true where id=$1 returning id`,
          [(result.rows[0] as { id: string }).id],
        )
      ).rows,
    ).toHaveLength(1);
  });
  it("coach cannot create event", async () => {
    await asUser(coach);
    await expect(
      db.query(
        `insert into public.events(name,location,start_date,end_date,registration_deadline,mode) values('Bad event','Test',current_date+20,current_date+20,now(),'OPEN_RING')`,
      ),
    ).rejects.toThrow(/row-level/);
  });
  it("admin cannot approve a mismatching category", async () => {
    await asUser(admin);
    await expect(
      insertRegistration({ status: "APPROVED", weight: 66 }),
    ).rejects.toThrow(/INVALID_CATEGORY/);
  });
  it("admin cannot approve without category", async () => {
    await asUser(admin);
    await expect(
      insertRegistration({ status: "APPROVED", category: null }),
    ).rejects.toThrow(/CATEGORY_REQUIRED/);
  });
  it("handles weight upper boundary in database", async () => {
    await asUser(admin);
    expect(
      (await insertRegistration({ status: "APPROVED", weight: 65 })).rows,
    ).toHaveLength(1);
  });
  it("excludes lower weight boundary in database", async () => {
    await asUser(admin);
    await expect(insertRegistration({ weight: 60 })).rejects.toThrow(
      /INVALID_CATEGORY/,
    );
  });
  it("coach cannot self-promote", async () => {
    await asUser(coach);
    expect(
      (
        await db.query(
          `update public.profiles set role='ADMIN' where id=$1 returning id`,
          [coach],
        )
      ).rows,
    ).toHaveLength(0);
    expect(
      (await db.query("select role from public.profiles where id=$1", [coach]))
        .rows,
    ).toEqual([{ role: "COACH" }]);
  });
  it("rejects late coach registration at database layer", async () => {
    await db.exec(
      `update public.events set registration_deadline=now()-interval '1 hour' where id='${event}'`,
    );
    await asUser(coach);
    await expect(insertRegistration()).rejects.toThrow(/REGISTRATION_CLOSED/);
  });
  it("coach cannot change approved registration", async () => {
    await asUser(admin);
    const r = await insertRegistration({ status: "APPROVED" });
    await asUser(coach);
    await expect(
      db.query(
        `update public.registrations set status='SUBMITTED' where id=$1`,
        [(r.rows[0] as { id: string }).id],
      ),
    ).rejects.toThrow(/REGISTRATION_LOCKED/);
  });
  it("prevents category edits after use", async () => {
    await asUser(admin);
    await insertRegistration();
    await expect(
      db.query("update public.categories set max_weight=70 where id=$1", [
        category,
      ]),
    ).rejects.toThrow(/CATEGORY_IN_USE/);
  });
  it("prevents event date edits after registration", async () => {
    await asUser(admin);
    await insertRegistration();
    await expect(
      db.query(
        "update public.events set start_date=start_date+1,end_date=end_date+1 where id=$1",
        [event],
      ),
    ).rejects.toThrow(/EVENT_DATE_LOCKED/);
  });
  it("audit logs do not contain registration payload", async () => {
    await asUser(admin);
    await insertRegistration();
    const rows = await db.query(
      `select action,entity_type from public.audit_logs where entity_type='registrations'`,
    );
    expect(rows.rows).toEqual([
      { action: "INSERT", entity_type: "registrations" },
    ]);
  });
  it("coach cannot forge audit logs", async () => {
    await asUser(coach);
    await expect(
      db.query(
        `insert into public.audit_logs(action,entity_type,entity_id) values('X','Y',$1)`,
        [ownAthlete],
      ),
    ).rejects.toThrow(/permission denied/);
  });
  it("coach cannot access draft or archived event", async () => {
    await db.query(`update public.events set status='DRAFT' where id=$1`, [
      event,
    ]);
    await asUser(coach);
    expect(
      (await db.query("select id from public.events where id=$1", [event]))
        .rows,
    ).toHaveLength(0);
  });
});
