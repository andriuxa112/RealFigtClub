import { readFileSync } from "node:fs";
import { PGlite } from "@electric-sql/pglite";
import { beforeEach, afterEach, it, expect } from "vitest";

let db: PGlite;
const fill = readFileSync(
  new URL("../supabase/fill-three-clubs.sql", import.meta.url),
  "utf8",
);
beforeEach(async () => {
  db = new PGlite();
  await db.exec(`
    create role anon;
    create role authenticated;
    create schema auth;
    create table auth.users(id uuid primary key, raw_user_meta_data jsonb default '{}');
    create function auth.uid() returns uuid language sql stable as $$select null::uuid$$;
  `);
  await db.exec(
    readFileSync(
      new URL(
        "../supabase/migrations/202611150001_initial.sql",
        import.meta.url,
      ),
      "utf8",
    ).replace("create extension if not exists pgcrypto;", ""),
  );
});
afterEach(async () => {
  await db.close();
});

async function counts() {
  return (
    await db.query<{ count: number }>(
      "select count(a.id)::integer as count from public.clubs c left join public.athletes a on a.club_id=c.id group by c.id order by c.id",
    )
  ).rows.map((r) => r.count);
}
async function existingClub() {
  const { rows } = await db.query<{ id: string }>(
    "insert into public.clubs(name,country,city,email) values('Existing club','LT','City','existing@example.invalid') returning id",
  );
  return rows[0].id;
}
it("creates exactly three clubs and four athletes each in an empty database", async () => {
  await db.exec(fill);
  expect(await counts()).toEqual([4, 4, 4]);
});
it("counts and preserves an existing club and its athlete without altering their data", async () => {
  const id = await existingClub();
  await db.query(
    "insert into public.athletes(club_id,first_name,last_name,date_of_birth,gender) values($1,'Existing','Athlete','2000-01-01','MALE')",
    [id],
  );
  const before = await db.query("select * from public.athletes");
  await db.exec(fill);
  expect(await counts()).toEqual([4, 4, 4]);
  const after = await db.query(
    "select * from public.athletes where first_name='Existing'",
  );
  expect(after.rows).toEqual(before.rows);
  expect(
    (await db.query("select name from public.clubs where id=$1", [id])).rows,
  ).toEqual([{ name: "Existing club" }]);
});
it("does not duplicate records when run twice", async () => {
  await db.exec(fill);
  const before = (await db.query("select id from public.athletes order by id"))
    .rows;
  await db.exec(fill);
  expect(await counts()).toEqual([4, 4, 4]);
  expect(
    (await db.query("select id from public.athletes order by id")).rows,
  ).toEqual(before);
});
it("refuses excess clubs without deleting or changing anything", async () => {
  await db.exec(
    "insert into public.clubs(name,country,city,email) select 'Existing '||n,'LT','City','x@example.invalid' from generate_series(1,4) n",
  );
  await expect(db.exec(fill)).rejects.toThrow(/ALREADY_OVER_TARGET/);
  await db.exec("rollback");
  expect(await counts()).toEqual([0, 0, 0, 0]);
});
it("refuses excess athletes without creating any new clubs", async () => {
  const id = await existingClub();
  await db.query(
    "insert into public.athletes(club_id,first_name,last_name,date_of_birth,gender) select $1,'Existing','Athlete '||n,'2000-01-01','MALE' from generate_series(1,5) n",
    [id],
  );
  await expect(db.exec(fill)).rejects.toThrow(/ALREADY_OVER_TARGET/);
  await db.exec("rollback");
  expect(await counts()).toEqual([5]);
});
