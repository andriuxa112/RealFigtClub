import { describe, it, expect } from "vitest";
import {
  ageOn,
  eligibleCategories,
  registrationSchema,
  canManageClub,
  type Category,
} from "../src/lib/domain";
const ids = {
  event: "10000000-0000-4000-8000-000000000001",
  discipline: "10000000-0000-4000-8000-000000000002",
  experience: "10000000-0000-4000-8000-000000000003",
  athlete: "10000000-0000-4000-8000-000000000004",
};
const category: Category = {
  id: "10000000-0000-4000-8000-000000000005",
  event_id: ids.event,
  discipline_id: ids.discipline,
  name: "Test category",
  gender: "MALE",
  min_age: 16,
  max_age: 18,
  min_weight: 60,
  max_weight: 65,
  experience_level: ids.experience,
};
const athlete = { date_of_birth: "2008-11-16", gender: "MALE" as const };
const r = {
  event_id: ids.event,
  discipline_id: ids.discipline,
  experience_level: ids.experience,
  declared_weight: 65,
};
describe("Age on event date", () => {
  it("handles birthday boundaries", () => {
    expect(ageOn("2008-11-16", "2026-11-15")).toBe(17);
    expect(ageOn("2008-11-16", "2026-11-16")).toBe(18);
    expect(ageOn("2008-11-16", "2026-11-17")).toBe(18);
  });
  it("handles leap day without elapsed-day arithmetic", () => {
    expect(ageOn("2008-02-29", "2025-02-28")).toBe(16);
    expect(ageOn("2008-02-29", "2025-03-01")).toBe(17);
  });
});
describe("Category matching", () => {
  it("includes the upper weight boundary", () =>
    expect(
      eligibleCategories(athlete, r, "2026-11-15", [category]),
    ).toHaveLength(1));
  it("excludes the lower boundary and assigns adjacent category exactly once", () => {
    const lower = { ...category, id: "lower", min_weight: 55, max_weight: 60 };
    expect(
      eligibleCategories(athlete, { ...r, declared_weight: 60 }, "2026-11-15", [
        category,
        lower,
      ]),
    ).toEqual([lower]);
  });
  it("checks both age boundaries inclusively", () => {
    expect(
      eligibleCategories(athlete, r, "2024-11-16", [category]),
    ).toHaveLength(1);
    expect(
      eligibleCategories(athlete, r, "2027-11-16", [category]),
    ).toHaveLength(0);
  });
  it("rejects wrong gender, discipline, event, and experience", () => {
    for (const change of [
      { gender: "FEMALE" },
      { discipline_id: "other" },
      { event_id: "other" },
      { experience_level: "other" },
    ])
      expect(
        eligibleCategories(athlete, r, "2026-11-15", [
          { ...category, ...change } as Category,
        ]),
      ).toHaveLength(0);
  });
  it("returns overlapping candidates without arbitrary selection", () =>
    expect(
      eligibleCategories(athlete, r, "2026-11-15", [
        category,
        { ...category, id: "second" },
      ]),
    ).toHaveLength(2));
  it("rejects negative weight and wins above total fights", () => {
    const base = {
      ...r,
      athlete_id: ids.athlete,
      category_id: null,
      total_fights: 2,
      total_wins: 3,
      status: "SUBMITTED",
    };
    expect(registrationSchema.safeParse(base).success).toBe(false);
    expect(
      registrationSchema.safeParse({
        ...base,
        total_wins: 0,
        declared_weight: -1,
      }).success,
    ).toBe(false);
  });
});
describe("Club authorization", () => {
  it("allows own club and admin, denies other clubs", () => {
    expect(canManageClub("COACH", ["own"], "own")).toBe(true);
    expect(canManageClub("COACH", ["own"], "other")).toBe(false);
    expect(canManageClub("ADMIN", [], "other")).toBe(true);
  });
});
