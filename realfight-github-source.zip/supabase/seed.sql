-- FICTIONAL DATA ONLY. Explicitly run against a disposable development database.
-- No auth users or passwords are created. See README for coach assignment.
begin;
insert into public.disciplines(id,name) values
 ('d0000000-0000-4000-8000-000000000001','Boxing'),('d0000000-0000-4000-8000-000000000002','Kickboxing'),('d0000000-0000-4000-8000-000000000003','K-1');
insert into public.experience_levels(id,name) values
 ('e0000000-0000-4000-8000-000000000001','Test beginner'),('e0000000-0000-4000-8000-000000000002','Test experienced');
insert into public.clubs(id,name,country,city,email,phone)
select ('c0000000-0000-4000-8000-'||lpad(n::text,12,'0'))::uuid,'Test Club '||n,'Lithuania',(array['Vilnius','Kaunas','Klaipėda','Šiauliai','Panevėžys'])[n],'club'||n||'@example.invalid','' from generate_series(1,5) n;
insert into public.athletes(id,club_id,first_name,last_name,date_of_birth,gender)
select ('a0000000-0000-4000-8000-'||lpad(n::text,12,'0'))::uuid,('c0000000-0000-4000-8000-'||lpad(((n-1)%5+1)::text,12,'0'))::uuid,'Test Athlete '||n,'Example',make_date(2000+n%10,1+n%12,1+n%27),case when n%2=0 then 'FEMALE' else 'MALE' end from generate_series(1,30) n;
insert into public.events(id,name,location,start_date,end_date,registration_deadline,mode,status) values
 ('f0000000-0000-4000-8000-000000000001','Test Open Ring','Vilnius',current_date+60,current_date+60,now()+interval '50 days','OPEN_RING','OPEN'),
 ('f0000000-0000-4000-8000-000000000002','Test Championship','Kaunas',current_date+90,current_date+91,now()+interval '80 days','CHAMPIONSHIP','OPEN');
insert into public.event_disciplines(event_id,discipline_id) select e.id,d.id from public.events e cross join public.disciplines d where e.id in ('f0000000-0000-4000-8000-000000000001','f0000000-0000-4000-8000-000000000002');
-- Illustrative administrator-defined bounds; these are NOT official sporting rules.
insert into public.categories(event_id,discipline_id,name,gender,min_age,max_age,min_weight,max_weight,experience_level)
select e.id,d.id,'Test '||g||' '||w||'kg '||x.name,g,16,40,w-10,w,x.id from public.events e cross join public.disciplines d cross join public.experience_levels x cross join unnest(array['MALE','FEMALE']) g cross join unnest(array[60,70,80,90]) w where e.id in ('f0000000-0000-4000-8000-000000000001','f0000000-0000-4000-8000-000000000002');
commit;
