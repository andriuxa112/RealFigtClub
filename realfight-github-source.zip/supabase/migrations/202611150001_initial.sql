begin;
create extension if not exists pgcrypto;
create type public.app_role as enum ('ADMIN','COACH');
create type public.event_mode as enum ('OPEN_RING','CHAMPIONSHIP');
create type public.event_status as enum ('DRAFT','OPEN','CLOSED','FINISHED');
create type public.registration_status as enum ('DRAFT','SUBMITTED','APPROVED','REJECTED');
create table public.profiles(id uuid primary key references auth.users on delete cascade, full_name text not null default '' check(length(full_name)<=160), role public.app_role not null default 'COACH', created_at timestamptz not null default now());
create table public.clubs(id uuid primary key default gen_random_uuid(),name text not null unique,country text not null,city text not null,email text not null,phone text not null default '',created_at timestamptz not null default now());
create table public.club_members(id uuid primary key default gen_random_uuid(),club_id uuid not null references public.clubs on delete cascade,user_id uuid not null references public.profiles on delete cascade,role text not null default 'COACH' check(role='COACH'),unique(club_id,user_id));
create index on public.club_members(user_id);
create table public.athletes(id uuid primary key default gen_random_uuid(),club_id uuid not null references public.clubs,first_name text not null check(length(first_name) between 1 and 80),last_name text not null check(length(last_name) between 1 and 80),date_of_birth date not null check(date_of_birth<=current_date),gender text not null check(gender in ('MALE','FEMALE')),created_at timestamptz not null default now(),updated_at timestamptz not null default now());
create index on public.athletes(club_id);
create table public.events(id uuid primary key default gen_random_uuid(),name text not null,location text not null,start_date date not null,end_date date not null,registration_deadline timestamptz not null,mode public.event_mode not null,status public.event_status not null default 'DRAFT',archived boolean not null default false,created_at timestamptz not null default now(),check(end_date>=start_date),check((registration_deadline at time zone 'Europe/Vilnius')::date<=start_date));
create table public.disciplines(id uuid primary key default gen_random_uuid(),name text not null unique,is_active boolean not null default true);
create table public.experience_levels(id uuid primary key default gen_random_uuid(),name text not null unique,is_active boolean not null default true);
create table public.event_disciplines(id uuid primary key default gen_random_uuid(),event_id uuid not null references public.events on delete cascade,discipline_id uuid not null references public.disciplines,unique(event_id,discipline_id));
create table public.categories(id uuid primary key default gen_random_uuid(),event_id uuid not null,discipline_id uuid not null,name text not null,gender text not null check(gender in ('MALE','FEMALE')),min_age integer not null check(min_age>=0),max_age integer not null check(max_age<=120 and max_age>=min_age),min_weight numeric(6,2) not null check(min_weight>=0),max_weight numeric(6,2) not null check(max_weight<=500 and max_weight>min_weight),experience_level uuid not null references public.experience_levels,foreign key(event_id,discipline_id) references public.event_disciplines(event_id,discipline_id),unique(id,event_id,discipline_id),unique(event_id,discipline_id,name));
create table public.registrations(id uuid primary key default gen_random_uuid(),event_id uuid not null references public.events,athlete_id uuid not null references public.athletes,discipline_id uuid not null references public.disciplines,category_id uuid,declared_weight numeric(6,2) not null check(declared_weight>0 and declared_weight<=500),experience_level uuid not null references public.experience_levels,total_fights integer not null check(total_fights between 0 and 10000),total_wins integer not null default 0 check(total_wins>=0 and total_wins<=total_fights),coach_contact text not null default '' check(length(coach_contact)<=200),notes text not null default '' check(length(notes)<=1000),status public.registration_status not null default 'DRAFT',created_at timestamptz not null default now(),updated_at timestamptz not null default now(),unique(event_id,athlete_id,discipline_id),foreign key(event_id,discipline_id) references public.event_disciplines(event_id,discipline_id),foreign key(category_id,event_id,discipline_id) references public.categories(id,event_id,discipline_id));
create index on public.registrations(athlete_id);
create index on public.registrations(category_id);
alter table public.categories add unique(id,event_id);
create table public.brackets(id uuid primary key default gen_random_uuid(),event_id uuid not null references public.events,category_id uuid not null,status text not null default 'DRAFT' check(status in ('DRAFT','CONFIRMED','FINISHED')),created_at timestamptz not null default now(),unique(event_id,category_id),foreign key(category_id,event_id) references public.categories(id,event_id));
create table public.matches(id uuid primary key default gen_random_uuid(),event_id uuid not null references public.events,category_id uuid not null,bracket_id uuid references public.brackets,athlete_red_id uuid references public.athletes,athlete_blue_id uuid references public.athletes,round_number integer not null check(round_number>0),match_number integer not null check(match_number>0),status text not null default 'DRAFT' check(status in ('DRAFT','READY','FINISHED','BYE')),winner_id uuid references public.athletes,next_match_id uuid references public.matches,next_corner text check(next_corner in ('RED','BLUE')),foreign key(category_id,event_id) references public.categories(id,event_id),check(athlete_red_id is distinct from athlete_blue_id or (athlete_red_id is null and athlete_blue_id is null)),check(winner_id is null or winner_id=athlete_red_id or winner_id=athlete_blue_id),unique(event_id,category_id,round_number,match_number));
create table public.audit_logs(id uuid primary key default gen_random_uuid(),actor_id uuid references public.profiles on delete set null,action text not null,entity_type text not null,entity_id uuid not null,created_at timestamptz not null default now());
create index on public.audit_logs(created_at);
create function public.is_admin() returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.profiles where id=auth.uid() and role='ADMIN')$$;
create function public.owns_club(cid uuid) returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.club_members where user_id=auth.uid() and club_id=cid)$$;
create function public.owns_athlete(aid uuid) returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.athletes where id=aid and public.owns_club(club_id))$$;
create function public.event_visible(eid uuid) returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.events where id=eid and status<>'DRAFT' and not archived)$$;
create function public.new_profile() returns trigger language plpgsql security definer set search_path='' as $$begin insert into public.profiles(id,full_name) values(new.id,left(coalesce(new.raw_user_meta_data->>'full_name',''),160));return new;end$$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.new_profile();
create function public.valid_category(aid uuid,cid uuid,eid uuid,did uuid,w numeric,xid uuid) returns boolean language sql stable security definer set search_path='' as $$
select exists(select 1 from public.categories c join public.athletes a on a.id=aid join public.events e on e.id=eid where c.id=cid and c.event_id=eid and c.discipline_id=did and c.gender=a.gender and c.experience_level=xid and extract(year from age(e.start_date,a.date_of_birth)) between c.min_age and c.max_age and w>c.min_weight and w<=c.max_weight)$$;
create function public.guard_registration() returns trigger language plpgsql security definer set search_path='' as $$
declare ev public.events; allowed boolean; begin
 select * into ev from public.events where id=new.event_id for share;
 perform 1 from public.athletes where id=new.athlete_id for share;
 if new.category_id is not null then perform 1 from public.categories where id=new.category_id for share;end if;
 if not public.is_admin() and auth.uid() is not null then
   if not public.owns_athlete(new.athlete_id) then raise exception 'FORBIDDEN';end if;
   if ev.status<>'OPEN' or ev.archived or ev.registration_deadline<now() then raise exception 'REGISTRATION_CLOSED';end if;
   if new.status not in ('DRAFT','SUBMITTED') then raise exception 'FORBIDDEN_STATUS';end if;
   if tg_op='UPDATE' and (old.status not in ('DRAFT','SUBMITTED') or old.athlete_id<>new.athlete_id or old.event_id<>new.event_id) then raise exception 'REGISTRATION_LOCKED';end if;
 end if;
 if new.category_id is not null then
  allowed=public.valid_category(new.athlete_id,new.category_id,new.event_id,new.discipline_id,new.declared_weight,new.experience_level);
  if not allowed then raise exception 'INVALID_CATEGORY';end if;
 end if;
 if new.status='APPROVED' and new.category_id is null then raise exception 'CATEGORY_REQUIRED';end if;
 new.updated_at=now();return new;
end$$;
create trigger validate_registration before insert or update on public.registrations for each row execute function public.guard_registration();
create function public.guard_athlete() returns trigger language plpgsql security definer set search_path='' as $$begin
 if tg_op='UPDATE' then
  if new.club_id<>old.club_id then raise exception 'CLUB_TRANSFER_REQUIRES_MIGRATION';end if;
  if exists(select 1 from public.registrations where athlete_id=old.id and status='APPROVED') and (new.gender<>old.gender or new.date_of_birth<>old.date_of_birth) then raise exception 'APPROVED_REGISTRATION_LOCK';end if;
 end if;
 new.updated_at=now();return new;end$$;
create trigger validate_athlete before insert or update on public.athletes for each row execute function public.guard_athlete();
create function public.guard_category() returns trigger language plpgsql security definer set search_path='' as $$begin
 if exists(select 1 from public.registrations where category_id=old.id) then raise exception 'CATEGORY_IN_USE';end if;return new;end$$;
create trigger validate_category before update on public.categories for each row execute function public.guard_category();
create function public.guard_event() returns trigger language plpgsql security definer set search_path='' as $$begin
 if new.start_date<>old.start_date and exists(select 1 from public.registrations where event_id=old.id) then raise exception 'EVENT_DATE_LOCKED';end if;return new;end$$;
create trigger validate_event before update on public.events for each row execute function public.guard_event();
create function public.audit_change() returns trigger language plpgsql security definer set search_path='' as $$begin
 insert into public.audit_logs(actor_id,action,entity_type,entity_id) values(auth.uid(),tg_op,tg_table_name,case when tg_op='DELETE' then old.id else new.id end);return coalesce(new,old);end$$;
do $$declare t text;begin
 foreach t in array array['profiles','clubs','club_members','athletes','events','disciplines','experience_levels','event_disciplines','categories','registrations','matches','brackets','audit_logs'] loop
  execute format('alter table public.%I enable row level security',t);
  execute format('revoke all on public.%I from anon',t);
  execute format('grant select,insert,update,delete on public.%I to authenticated',t);
  if t<>'audit_logs' then execute format('create trigger audit_row after insert or update or delete on public.%I for each row execute function public.audit_change()',t);end if;
 end loop;end$$;
create policy profiles_read on public.profiles for select to authenticated using(id=auth.uid() or public.is_admin());
-- Roles can only be changed by a database owner / service process, never by a browser.
create policy clubs_read on public.clubs for select to authenticated using(public.is_admin() or public.owns_club(id));
create policy clubs_admin on public.clubs for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy members_read on public.club_members for select to authenticated using(public.is_admin() or user_id=auth.uid());
create policy members_admin on public.club_members for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy athletes_access on public.athletes for all to authenticated using(public.is_admin() or public.owns_club(club_id)) with check(public.is_admin() or public.owns_club(club_id));
create policy events_read on public.events for select to authenticated using(public.is_admin() or (status<>'DRAFT' and not archived));
create policy events_admin on public.events for all to authenticated using(public.is_admin()) with check(public.is_admin());
do $$declare t text;begin foreach t in array array['disciplines','experience_levels'] loop
 execute format('create policy reference_read on public.%I for select to authenticated using(true)',t);
 execute format('create policy reference_admin on public.%I for all to authenticated using(public.is_admin()) with check(public.is_admin())',t);
end loop;end$$;
do $$declare t text;begin foreach t in array array['event_disciplines','categories'] loop
 execute format('create policy event_read on public.%I for select to authenticated using(public.is_admin() or public.event_visible(event_id))',t);
 execute format('create policy event_admin on public.%I for all to authenticated using(public.is_admin()) with check(public.is_admin())',t);
end loop;end$$;
create policy registration_read on public.registrations for select to authenticated using(public.is_admin() or public.owns_athlete(athlete_id));
create policy registration_insert on public.registrations for insert to authenticated with check(public.is_admin() or public.owns_athlete(athlete_id));
create policy registration_update on public.registrations for update to authenticated using(public.is_admin() or public.owns_athlete(athlete_id)) with check(public.is_admin() or public.owns_athlete(athlete_id));
create policy registration_delete on public.registrations for delete to authenticated using(public.is_admin());
-- Pairing / results writes intentionally remain disabled in phase I.
create policy matches_read on public.matches for select to authenticated using(public.is_admin());
create policy brackets_read on public.brackets for select to authenticated using(public.is_admin());
create policy audit_read on public.audit_logs for select to authenticated using(public.is_admin());
revoke insert,update,delete on public.audit_logs from authenticated;
revoke all on function public.new_profile(),public.guard_registration(),public.guard_athlete(),public.guard_category(),public.guard_event(),public.audit_change() from public;
revoke all on function public.is_admin(),public.owns_club(uuid),public.owns_athlete(uuid),public.event_visible(uuid),public.valid_category(uuid,uuid,uuid,uuid,numeric,uuid) from public;
grant execute on function public.is_admin(),public.owns_club(uuid),public.owns_athlete(uuid),public.event_visible(uuid),public.valid_category(uuid,uuid,uuid,uuid,numeric,uuid) to authenticated;
commit;
