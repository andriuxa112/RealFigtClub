-- Run ONLY in REAL FIGHT project lukzxacaqryhdwyyxstu.
-- Explicitly requested fictional fixtures; never part of automatic migrations.
-- Preserves existing clubs and athletes. Repeat execution adds no duplicates.
begin;

lock table public.clubs, public.athletes in share row exclusive mode;

do $$
declare
  club_count integer;
  athlete_count integer;
  club_row record;
  club_number integer := 0;
  candidate integer;
  candidate_last_name text;
  city_names text[] := array['Vilniaus', 'Kauno', 'Klaipėdos'];
  city_values text[] := array['Vilnius', 'Kaunas', 'Klaipėda'];
begin
  select count(*) into club_count from public.clubs;
  if club_count > 3 then
    raise exception 'ALREADY_OVER_TARGET: already % clubs; nothing was changed.', club_count;
  end if;
  if exists (
    select 1 from public.athletes group by club_id having count(*) > 4
  ) then
    raise exception 'ALREADY_OVER_TARGET: a club already has more than 4 athletes; nothing was changed.';
  end if;

  for candidate in 1..3 loop
    exit when club_count = 3;
    insert into public.clubs(name, country, city, email, phone)
    values (
      city_names[candidate] || ' testinis klubas',
      'Lietuva', city_values[candidate],
      'test-club-' || candidate || '@example.invalid', ''
    )
    on conflict (name) do nothing;
    select count(*) into club_count from public.clubs;
  end loop;

  for club_row in select id from public.clubs order by created_at, id loop
    club_number := club_number + 1;
    select count(*) into athlete_count from public.athletes where club_id = club_row.id;
    candidate := 0;
    while athlete_count < 4 loop
      candidate := candidate + 1;
      candidate_last_name := 'Kovotojas ' || club_number || '-' || lpad(candidate::text, 2, '0');
      if exists (
        select 1 from public.athletes
        where club_id = club_row.id
          and first_name = 'Testinis' and last_name = candidate_last_name
      ) then
        continue;
      end if;
      insert into public.athletes(club_id, first_name, last_name, date_of_birth, gender)
      values (
        club_row.id, 'Testinis', candidate_last_name,
        make_date(2000 + (club_number + candidate) % 6, 1 + candidate % 12, 1 + candidate % 27),
        case when candidate % 2 = 0 then 'FEMALE' else 'MALE' end
      );
      athlete_count := athlete_count + 1;
    end loop;
  end loop;
end $$;

commit;

select c.name as club, count(a.id)::integer as athletes
from public.clubs c
left join public.athletes a on a.club_id = c.id
group by c.id, c.name
order by c.name;
